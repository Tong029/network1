clc
clear all
close all
for i = 1:5
    [rmse(i),r2(i)] = trfunct(i);    
end
